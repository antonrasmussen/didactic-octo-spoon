/**
 * A collection of CS 330 Java Examples.
 */
package edu.odu.cs.cs330.examples;