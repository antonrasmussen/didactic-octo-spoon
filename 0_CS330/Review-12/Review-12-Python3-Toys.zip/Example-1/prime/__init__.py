"""
Prime number manipulation and generation
"""
